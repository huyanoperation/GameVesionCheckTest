----------------------------------------------------------
---------------------Disperse Components--------------------


function getDisperseComponents()
    return "{\"PLAYERLEAVEPOS1\":20,\"PLAYERLEAVEPOS2\":21, \"PLAYERLEAVEPOS3\":23, \"PLAYERLEAVEPOS4\":24, \"PLAYERLEAVEPOS5\":22}"
end
----------------------------------------------------------
function getAssemblyComponents()
    return "{\"PLAYERLEAVEPOS1\":15,\"PLAYERLEAVEPOS2\":18, \"PLAYERLEAVEPOS3\":17, \"PLAYERLEAVEPOS4\":16, \"PLAYERLEAVEPOS5\":19}"
end
-----------------------------------------------------------
function getGatherMoveEndStateTime()
    return "5"
end

-----------------------------------------------------------
function getGamePublicSkillCDTime()
    return 4
end

-----------------------------------------------------------
function getGameAdjustingAttackRange()
    return 2
end

-----------------------------------------------------------
function getFightMapMoveSpeedScale()
    return "{\"MAP_FRONT\":2,\"MAP_MID\":1, \"MAP_BACK\":0.5}"
end