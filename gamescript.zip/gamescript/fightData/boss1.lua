---------------------------------------
----- these functions called by c++ --
---------------------------------------
function getBoss1HpScale()
return 0.5
end

--------------------------------------
function getBoss1SecondStateAttackOnceAtime()
return 30
end

--------------------------------------
function getBoss1Monster1Num()
return 4
end

--------------------------------------
function getBoss1Monster1ID()
return 6
end

--------------------------------------
function getBossSpawnMonstertime()
return 20
end

--------------------------------------
function getBoss1Monster2Num()
return 4
end

--------------------------------------
function getBoss1Monster2ID()
return 7
end

-------------------------------------------
function getBoss1HP()
return 5000
end

-------------------------------------- attack ----------------------------------------
function getBoss1AttackPosition()
return "{\"posX\":1000,\"posY\":700}"
end

function getBoss1AttackFireEffect()
return "{\"effectID\":4,\"effectname\":\"HuoQiu\"}"
end

function getBoss1AttackFireBurstEffect()
return "{\"effectID\":3,\"effectname\":\"Bomb\"}"
end

function getBoss1AttackPositionIcon()
return "{\"effectID\":4,\"effectname\":\"HuoQuan\"}"
end

function getBoss1AttackToPosition()
return "{\"posX\":400,\"posY\":400}"
end

function getBoss1AttackTime()
return 1.7
end

function getBoss1AttackRange()
return 20
end

function getBoss1AttackRangeHeight()
return 5
end

function getBoss1RingIconScale()
return 3
end

function getBoss1BeforeAttackShowSignTime()
return 5.0
end

function getBoss1FireAtk()
return 400
end

function getBoss1SpawnMonsterPosName()
return "{ \"SpawnPosName\":[ \"ENEMYPOS1\", \"ENEMYPOS3\", \"ENEMYPOS4\", \"ENEMYPOS6\" ] }"
end
----------------------------------------boss  animation-------------------------------
function getBoss1FlyAnimation()
return "FLY_"
end


function getBoss1AttackFire()
return "BOMB_"
end


function getboss1FlyComeBackAnimation()
return "LAND_"
end

---------------------------------------------------------------------------------------