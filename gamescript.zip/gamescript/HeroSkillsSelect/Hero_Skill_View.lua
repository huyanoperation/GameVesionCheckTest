require "gamescript/extern"
require "gamescript/HeroSkillsSelect/CSkillsprite"
HeroSkillView = class("HeroSkillView")
HeroSkillView.__index = HeroSkillView
local property={cellSizeW=300,cellSizeH=530,numberOfCells=10,sizeMakeW=780,sizeMakeH=high,positionX=1000,positionY=80,widget=0}
local touchRect_1=0 --技能1矩形区域
local touchRect_2=0 --技能2矩形区域 
local touchRect_3=0 --技能3矩形区域
local tableViewTest=0 
local kSkillStateGrabbed = 0--是否吞噬触摸事件
local isSprite=0  
local isTouch={}--存储技能是否装备
--local spPointArray={}--技能图片Position
local equipSkillArray={}
local layer=0
local tableArray = {}
local equipSkillTouch=0 --点击已装备区域
local CSkillSprite = require "gamescript/HeroSkillsSelect/CSkillsprite"
local unEquipskillTouch = 0 --点击未装备区域
for i=0,property.numberOfCells do
   isTouch[i]=0
end

function HeroSkillView.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, HeroSkillView)
    return target
end
-------------------------------------------------------------------------tableView Create--------------------------------------------------
function HeroSkillView:init()
    self:setTouchEnabled(true)--layer touch
    self:registerScriptTouchHandler(onTouch)
    self:setTouchMode(kCCTouchesOneByOne)--独占Touch
    local winSize = CCDirector:sharedDirector():getWinSize()
    tableView = CCTableView:create(CCSizeMake(property.sizeMakeW,property.sizeMakeH))--tableView长，宽
    tableViewTest=tableView
    tableView:setTag(111)
    tableView:setDirection(kCCScrollViewDirectionVertical)
    tableView:setPosition(CCPointMake(property.positionX,property.positionY))
    tableView:setVerticalFillOrder(kCCTableViewFillTopDown)
    self:addChild(tableView)
    tableView:registerScriptHandler(HeroSkillView.scrollViewDidScroll,CCTableView.kTableViewScroll)
    tableView:registerScriptHandler(HeroSkillView.scrollViewDidZoom,CCTableView.kTableViewZoom)
    tableView:registerScriptHandler(HeroSkillView.tableCellTouched,CCTableView.kTableCellTouched)
    tableView:registerScriptHandler(HeroSkillView.cellSizeForTable,CCTableView.kTableCellSizeForIndex)
    tableView:registerScriptHandler(HeroSkillView.tableCellAtIndex,CCTableView.kTableCellSizeAtIndex)
    tableView:registerScriptHandler(HeroSkillView.numberOfCellsInTableView,CCTableView.kNumberOfCellsInTableView)
    tableView:reloadData()
    return true
end

function HeroSkillView.create(table)
 
    property=table
    layer = HeroSkillView.extend(CCLayer:create())
    if nil ~= layer then
        layer:init()
    end
   equipskill_1=property.widget:getChildByName("SkillChoosed1")
   skillPosition_1 = equipskill_1:getPosition()
   skillContent_1= equipskill_1:getContentSize()
   touchRect_1 = CCRectMake(-skillContent_1.width / 2 + skillPosition_1.x, -skillContent_1.height / 2 + skillPosition_1.y, skillContent_1.width, skillContent_1.height)

   equipskill_2=property.widget:getChildByName("SkillChoosed2")
   skillPosition_2 = equipskill_2:getPosition()
   skillContent_2= equipskill_2:getContentSize()
   touchRect_2 = CCRectMake(-skillContent_2.width / 2 + skillPosition_2.x, -skillContent_2.height / 2 + skillPosition_2.y, skillContent_2.width, skillContent_2.height)

   equipskill_3=property.widget:getChildByName("SkillChoosed3")
   skillPosition_3 = equipskill_3:getPosition()
   skillContent_3= equipskill_3:getContentSize()
   touchRect_3 = CCRectMake(-skillContent_3.width / 2 + skillPosition_3.x, -skillContent_3.height / 2 + skillPosition_3.y, skillContent_3.width, skillContent_3.height)

   tableX,tableY=tableViewTest:getPosition()
   tableContent=tableViewTest:getContentSize()
   tableViewRect=CCRectMake(-tableContent.width/2+tableX,-tableContent.height/2+tableY,tableContent.width,tableContent.height)
   --layer:setPosition(ccp(1358,476))


        local  removeAllSkllMenu = CCMenu:create()
        local  removeAllSkllitem = CCMenuItemImage:create("data/ui/GUI/button.png","data/ui/GUI/button.png")
        removeAllSkllitem:registerScriptTapHandler(HeroSkillView.removeAllSkll)
        removeAllSkllMenu:addChild(removeAllSkllitem)
        removeAllSkllMenu:setPosition(ccp(850, 100))
        --buttonMenu:alignItemsHorizontally()
        layer:addChild(removeAllSkllMenu)

   return layer
end
-------------------------------------------------------------------------tableView Protocol----------------------------------------------
function HeroSkillView.scrollViewDidScroll(view)
--    print("HeroSkillView_Skill--scrollViewDidScroll")
end

function HeroSkillView.scrollViewDidZoom(view)
--    print("HeroSkillView_Skill--scrollViewDidZoom")
end

function HeroSkillView.tableCellTouched(table,cell)
 --   print("HeroSkillView_Skill--cell touched at index: " .. cell:getIdx())
end

function HeroSkillView.cellSizeForTable(table,idx) --设置每个cell的大小
    return property.cellSizeW,property.cellSizeH
end

function HeroSkillView.numberOfCellsInTableView(table)
   return property.numberOfCells
end

function HeroSkillView.removeAllSkll()

   local childArray =layer:getChildren()
   local  len = childArray:count()-1
   for i=len,0,-1 do
      local tempchild = tolua.cast(childArray:objectAtIndex(i),"CCSprite")
      if tempchild ~= nil and ( tempchild:getTag()==11 or tempchild:getTag()==22 or tempchild:getTag()==33 ) then
           layer:removeChild(tempchild,true)
        end
   end

   for i=0,property.numberOfCells do
      isTouch[i]=0
   end

end

function HeroSkillView.menuCallback1()
     print("menuCallback1")
end

function HeroSkillView.menuCallback2()
     print("menuCallback2")
end
----------------------------------------------------------------tableViewCell---------------------------------------------------------------------
function HeroSkillView.tableCellAtIndex(table, idx)
  local  cell = tableView:dequeueCell()
    if nil == cell then
        cell = CCTableViewCell:new()

        local skillTexture = CCTextureCache:sharedTextureCache():addImage("data/ui/qunliao.png")
        local spriteSkill = CSkillSprite:skillWithTexture(skillTexture)
        spriteSkill:setPosition( ccp(100,80))
        spriteSkill:setTag(88)
        cell:addChild(spriteSkill)

        local strValue = string.format("%d",idx)
        local label = nil
        label = CCLabelTTF:create(""..strValue, "Helvetica", 30.0)
        label:setPosition(CCPointMake(300,160))
        label:setAnchorPoint(CCPointMake(0,0))
        label:setTag(10001)
        cell:addChild(label)

        local  buttonMenu = CCMenu:create()
        local  item1 = CCMenuItemImage:create("data/ui/GUI/button.png","data/ui/GUI/button.png")
        item1:registerScriptTapHandler(HeroSkillView.menuCallback1)
        buttonMenu:addChild(item1)

        local  item2 = CCMenuItemImage:create("data/ui/GUI/button.png","data/ui/GUI/button.png")
        item2:registerScriptTapHandler(HeroSkillView.menuCallback2)
        buttonMenu:addChild(item2)

        buttonMenu:setPosition(ccp(650, 0))
        buttonMenu:alignItemsHorizontally()
        cell:addChild(buttonMenu)
    end
        local strValue = string.format("%d",idx)
        label = tolua.cast(cell:getChildByTag(10001),"CCLabelTTF")
        if nil ~= label then
            label:setString(strValue)
        end
    return cell
end
----------------------------------------------------------------------butto CallBack function-----------------------------------------
function HeroSkillView.removeNodeCallBack()
     layer:removeChild(spCopy,true)
end
--------------------------------------------------------------------------unEquip Skill Touchi---------------------------------------------


local function unEquipskillTouchEnd( x,y )
   
  unEquipskillTouch=0
end 

local function unEquipSkillTouchBegan(x,y)
  for i=0,property.numberOfCells-1 do
    cell=tableViewTest:cellAtIndex(i)
    if cell then
          sp=cell:getChildByTag(88)
          local wordPosition=sp:getWordLocation(true)
          if sp:containsTouchWordLocation(x,y) and isTouch[i]==0 then
              spCopy=CSkillSprite:cloneSprite(sp)
              spCopy:setBeforePosition(wordPosition.x,wordPosition.y)
              layer:addChild(spCopy)
              spCopy:setTag(i)
              isTouch[i]=1
              kSkillStateGrabbed=false
              isSprite=1
        else
              kSkillStateGrabbed=true
        end
    end
  end
end
-----------------------------------------------------------------------equip Skill touch----------------------------------------------------------
local function equipSkillTouchBegan(x,y)

    local childArray = layer:getChildren()
    local len =childArray:count()-1
    if touchRect_1:containsPoint(ccp(x,y)) then
      for i=0,len do
          local tempchild = tolua.cast(childArray:objectAtIndex(i),"CCSprite")
          local childx,childy =tempchild:getPosition()
          if touchRect_1:containsPoint(ccp(childx,childy)) and tempchild:getTag()~=111 then
              equipSkillTouch=1
                skillChild=CSkillSprite:cloneSprite(tempchild)
                local tempChildx,tempChildy=tempchild:getPosition()
                skillChild:setPosition(ccp(tempChildx,tempChildy))
                layer:addChild(skillChild)
          end
      end
    elseif touchRect_2:containsPoint(ccp(x,y)) then
      for i=0,len do
          local tempchild= tolua.cast(childArray:objectAtIndex(i),"CCSprite")
          local childx,childy =tempchild:getPosition()
         
          if touchRect_2:containsPoint(ccp(childx,childy)) and tempchild:getTag()~=111 then
                equipSkillTouch=1
                skillChild=CSkillSprite:cloneSprite(tempchild)
                local tempChildx,tempChildy=tempchild:getPosition()
                skillChild:setPosition(ccp(tempChildx,tempChildy))
                layer:addChild(skillChild)
          end
      end
    elseif touchRect_3:containsPoint(ccp(x,y)) then
      for i=0,len do
          local tempchild= tolua.cast(childArray:objectAtIndex(i),"CCSprite")
          local childx,childy =tempchild:getPosition()
         
          if touchRect_3:containsPoint(ccp(childx,childy)) and tempchild:getTag()~=111 then
                equipSkillTouch=1
                skillChild=CSkillSprite:cloneSprite(tempchild)
                local tempChildx,tempChildy=tempchild:getPosition()
                skillChild:setPosition(ccp(tempChildx,tempChildy))
                layer:addChild(skillChild)
          end
      end 
    else
      equipSkillTouch=0
      child=nil
    end
  
end
 
local function rect(sp1)
    local  s = sp1:getTexture():getContentSize()
    return CCRectMake(-s.width / 2, -s.height / 2, s.width, s.height)
end

 local function skillSwop(sp1,sp2,sp3,startX,startY,endx,endy)

   local sp1x,sp1y=sp1:getPosition() 
   local sp2x,sp2y=sp2:getPosition() 
   local sp3x,sp3y=sp3:getPosition() 
   local sp1Rect=sp2:rect(sp2)
   local sp2Rect=sp2:rect(sp2)
   local sp3Rect=sp2:rect(sp2)

   if sp1Rect:containsPoint(ccp(sp2x,sp2y)) then

      print("setPosition sp2  move  sp1")

   elseif sp1Rect:containsPoint(ccp(sp3x,sp3y)) then

      print("setPosition sp3  move  sp1")

   elseif sp2Rect:containsPoint(ccp(sp1x,sp1y)) then

      print("setPosition sp1  move  sp2")

   elseif sp2Rect:containsPoint(ccp(sp3x,sp3y)) then

      print("setPosition sp3  move  sp2")

   elseif sp3Rect:containsPoint(ccp(sp1x,sp1y)) then

      print("setPosition sp1  move  sp3")

   elseif sp3Rect:containsPoint(ccp(sp2x,sp2y)) then
      print("setPosition sp2  move  sp3")

   else

   end

 end



 local function equipskillTouchEnd( x,y )

  
  if touchRect_1:containsPoint(ccp(x,y)) or touchRect_2:containsPoint(ccp(x,y)) or touchRect_3:containsPoint(ccp(x,y)) then ----拖拽交换

  

  
  elseif tableViewRect:containsPoint(ccp(x,y)) then  ---拖拽删除

     if tableViewRect:intersectsRect(skillChild:boundingBox()) then
          local childArray =layer:getChildren()
          local  len = childArray:count()-1
          if skillChild ~= nil then 
           local  tag=skillChild:getTag()
            for i=0,len do
              local tempchild = tolua.cast(childArray:objectAtIndex(i),"CCSprite")
              if tag== tempchild:getTag() then
                 layer:removeChildByTag(tag,true)
              end
            end
          end
          skillChild=nil
          equipSkillTouch=0
     end
  end

end 

----------------------------------------------------------------------------touch------------------------------------------------------
function ccTouchBegan(x, y)
  
  if touchRect_1:containsPoint(ccp(x,y)) or touchRect_2:containsPoint(ccp(x,y)) or touchRect_3:containsPoint(ccp(x,y)) then --判断装备点击局域 
    equipSkillTouchBegan(x,y)
  else

    unEquipSkillTouchBegan(x,y)  --未装备技能点击区域
    unEquipskillTouch=1
  end
  return kSkillStateGrabbed;
end

function ccTouchMoved(x, y)

  if unEquipskillTouch==1 then
       if isSprite==1 then
          spCopy:setPosition(x,y)
       end
  end

  if equipSkillTouch==1 then
       skillChild:setPosition(x,y)
  end
end

function ccTouchEnded(x, y)
  
  if isSprite==1 then 
    local spPosition=spCopy:getPosition()

    if touchRect_1:containsPoint(ccp(x,y)) then

     spCopy:setPosition(ccp(skillPosition_1.x,skillPosition_1.y))
     spCopy:setBeforePosition(skillPosition_1.x,skillPosition_1.y)
     spCopy:setTag(11)
     
    elseif touchRect_2:containsPoint(ccp(x,y)) then

      spCopy:setPosition(ccp(skillPosition_2.x,skillPosition_2.y))
      spCopy:setBeforePosition(skillPosition_2.x,skillPosition_2.y)
      spCopy:setTag(22)
     
    elseif touchRect_3:containsPoint(ccp(x,y)) then

      spCopy:setPosition(ccp(skillPosition_3.x,skillPosition_3.y))
      spCopy:setBeforePosition(skillPosition_3.x,skillPosition_3.y)
      spCopy:setTag(33)

    else
      local tag=spCopy:getTag()
      for i=0,property.numberOfCells do
          if i==tag then
            isTouch[i]=0
            local position = spCopy:getBeforePosition()
            local move= CCMoveTo:create(0.1,position)
            local callfunc = CCCallFunc:create(HeroSkillView.removeNodeCallBack)
            local sequence = CCSequence:createWithTwoActions(move, callfunc)
            local action = CCRepeatForever:create(sequence)
            spCopy:runAction(action)
          end
       end
    end
    isSprite=0
  end
    print("ENDequipSkillTouch="..equipSkillTouch)
    if equipSkillTouch==1 then
       equipskillTouchEnd(x,y)
  end
end

 function onTouch(eventType, x, y)
    if eventType == "began" then
        return ccTouchBegan(x,y)

    elseif eventType == "moved" then
        return ccTouchMoved(x,y)

    elseif eventType == "ended" then
        return ccTouchEnded(x, y)

    end
end

