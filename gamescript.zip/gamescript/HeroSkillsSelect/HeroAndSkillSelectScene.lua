

HeroAndSkillSelectScene = class( "HeroAndSkillSelectScene", function()
  return CCScene:create()
end )

HeroAndSkillSelectScene.__index = HeroAndSkillSelectScene
HeroAndSkillSelectScene.uiLayer = 0

-----------------------------------读起英雄选择菜单UI--------------------------------------

function HeroAndSkillSelectScene:LoadUI()
   print("HeroAndSkillSelectScene——UI LOAD")
   local uiLayer =  UILayer:create()
   HeroAndSkillSelectScene.uiLayer = uiLayer
   self:addChild( uiLayer, 1 )
   local pUIWidget = GUIReader:shareReader():widgetFromJsonFile("data/ui/UI_skillChoose_1.json");
   local PlayerHead1 = pUIWidget:getChildByName("PlayerHead1")
   local Point1 = PlayerHead1:getPosition()
   local PlayerHead2 = pUIWidget:getChildByName("PlayerHead2")
   local Point2 = PlayerHead2:getPosition()
   local distance = Point1.y-Point2.y --两个Cell的距离
   local high=50*5+distance*4  --tableView的高度
   local property={cellSizeW=180,cellSizeH=distance,numberOfCells=10,sizeMakeW=200,sizeMakeH=high,positionX=10,positionY=80}--positionX=Point1.x,positionY=Point1.y
   local headTableView = HeroHeadTableLayer.create(property)
   uiLayer:addChild(headTableView)

   pUIWidget:getChildByName("BattleButton"):registerEventScript(HeroAndSkillSelectScene.onBattleSceneButtonCallBack)
   local playerSkill = pUIWidget:getChildByName("Skill1")
   local skillPoint = playerSkill:getPosition()
   local equipSkill=pUIWidget:getChildByName("SkillChoosed1")
   local equipSkillpoint=equipSkill:getPosition()
   local equipSkillContentSize=equipSkill:getContentSize()
   local skillProperty={cellSizeW=300,cellSizeH=530,numberOfCells=10,sizeMakeW=780,sizeMakeH=high,positionX=1000,positionY=80,widget=pUIWidget}--positionX=skillPoint.x,positionY=skillPoint.y
   local skillTableView= HeroSkillView.create(skillProperty)
   uiLayer:addChild(skillTableView)
   uiLayer:addWidget( pUIWidget )
end

---------------------------------- 英雄 技能 函数 called by c++ ---------------------------------------

function HeroAndSkillSelectScene.onHeroAndSkillSelectSceneEvnet( eventType )
    if( eventType == "enter" ) then
        g_HeroAndSkillSelectScene:LoadUI()
    end
end

---------------------------------- 进入战场入口 called by c++ ----------------------------------------

function HeroAndSkillSelectScene.onBattleSceneButtonCallBack( eventType)
   print("进入战场入口")
end





