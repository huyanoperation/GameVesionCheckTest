require "gamescript/extern"
HeroHeadTableLayer = class("HeroHeadTableLayer")
HeroHeadTableLayer.__index = HeroHeadTableLayer
local  property={cellSizeW=0,cellSizeH=0,numberOfCells=0,sizeMakeW=0,sizeMakeH=0,positionX=0,positionY=0}

HeroHeadTableLayer.colortest = 10
function HeroHeadTableLayer.extend(target)
    local t = tolua.getpeer(target)
    if not t then
        t = {}
        tolua.setpeer(target, t)
    end
    setmetatable(t, HeroHeadTableLayer)
    return target
end

function HeroHeadTableLayer:init()

    local winSize = CCDirector:sharedDirector():getWinSize()

    tableView = CCTableView:create(CCSizeMake(property.sizeMakeW,property.sizeMakeH))--tableView长，宽
    tableView:setDirection(kCCScrollViewDirectionVertical)
    tableView:setAnchorPoint(CCPointMake(0,0))
    tableView:setPosition(CCPointMake(property.positionX,property.positionY))
    tableView:setVerticalFillOrder(kCCTableViewFillTopDown)
    self:addChild(tableView)
    tableView:registerScriptHandler(HeroHeadTableLayer.scrollViewDidScroll,CCTableView.kTableViewScroll)
    tableView:registerScriptHandler(HeroHeadTableLayer.scrollViewDidZoom,CCTableView.kTableViewZoom)
    tableView:registerScriptHandler(HeroHeadTableLayer.tableCellTouched,CCTableView.kTableCellTouched)
    tableView:registerScriptHandler(HeroHeadTableLayer.cellSizeForTable,CCTableView.kTableCellSizeForIndex)
    tableView:registerScriptHandler(HeroHeadTableLayer.tableCellAtIndex,CCTableView.kTableCellSizeAtIndex)
    tableView:registerScriptHandler(HeroHeadTableLayer.numberOfCellsInTableView,CCTableView.kNumberOfCellsInTableView)
    tableView:reloadData()


    print( "colortest"..self.colortest )

    return true
end

function HeroHeadTableLayer.create(var)
    property=var
     print("HeroHeadTableLayer_TableView->Create()")
    local layer = HeroHeadTableLayer.extend(CCLayer:create())
    if nil ~= layer then
        layer:init()
    end
   
    return layer
end

function HeroHeadTableLayer.scrollViewDidScroll(view)
  --  print("HeroHeadTableLayer_scrollViewDidScroll")
end

function HeroHeadTableLayer.scrollViewDidZoom(view)
  --  print("HeroHeadTableLayer_scrollViewDidZoom")
end

function HeroHeadTableLayer.tableCellTouched(table,cell)
   -- print("HeroHeadTableLayer_cell touched at index: " .. cell:getIdx())
   
end

function HeroHeadTableLayer.cellSizeForTable(table,idx) --设置每个cell的大小
    return property.cellSizeW,property.cellSizeH
end

function HeroHeadTableLayer.numberOfCellsInTableView(table)
   return property.numberOfCells
end

function HeroHeadTableLayer.tableCellAtIndex(table, idx)

    local  cell = tableView:dequeueCell()
    if nil == cell then
        cell = CCTableViewCell:new()
        local sprite = CCSprite:create("data/ui/dunqiang.png")
        sprite:setAnchorPoint(CCPointMake(0,0))
        sprite:setPosition(CCPointMake(0, 0))
        cell:addChild(sprite)
    end
    return cell
end



