require "gamescript/extern"

local CSkillSprite = class("CSkillSprite", function(texture)
    return CCSprite:createWithTexture(texture)
end)

CSkillSprite.__index = CSkillSprite

CSkillSprite.beforPointX=0
CSkillSprite.beforPointY=0

function CSkillSprite:rect()
    local  s = self:getTexture():getContentSize()
    return CCRectMake(-s.width / 2, -s.height / 2, s.width, s.height)
end

function CSkillSprite:containsTouchLocation(x,y) --点击坐标
    print("containsTouchLocationx="..x.."containsTouchLocationy="..y)
    local position = ccp(self:getPosition())
    local  s = self:getTexture():getContentSize()
    local touchRect = CCRectMake(-s.width / 2 + position.x, -s.height / 2 + position.y, s.width, s.height)
    local b = touchRect:containsPoint(ccp(x,y))
    return b
end

function CSkillSprite:containsTouchWordLocation(x,y) --世界坐标
    local position = ccp(self:getPosition())
    local  s = self:getTexture():getContentSize()
    local newPosition =self:getParent():convertToWorldSpace(position)
    local touchRect = CCRectMake(-s.width / 2 + newPosition.x, -s.height / 2 + newPosition.y, s.width, s.height)
    local b = touchRect:containsPoint(ccp(x,y))
    return b
end

function CSkillSprite:getWordLocation(var)--var true 转换当前坐标点  false 转化之前坐标点
    if var then
        local position = ccp(self:getPosition())
        local newPosition=self:getParent():convertToWorldSpace(position)
        return newPosition
    else
        local position= self:getBeforePosition()
        local newPosition=self:getParent():convertToWorldSpace(position)
        return newPosition
    end

end

function CSkillSprite:setBeforePosition(x,y)  --移动之前坐标点
    self.beforPointX=x
    self.beforPointY=y
end

function CSkillSprite:getBeforePosition() 
    return CCPointMake(self.beforPointX,self.beforPointY)
end


function CSkillSprite:skillWithTexture(aTexture)
    print("create sprite~~~~~~")
    local skill = CSkillSprite.new(aTexture);
    return skill;
end

function CSkillSprite:cloneSprite(aSprite)-------copy Spite

    local newtexture=aSprite:getTexture()

    local newSkill = self:skillWithTexture(newtexture)
    newSkill:setTag(aSprite:getTag())
    return newSkill

end

return CSkillSprite


--[[  创建精灵方法

 local skillTexture = CCTextureCache:sharedTextureCache():addImage("资源文件名");
    
 local skill = CSkillSprite:skillWithTexture(skillTexture);

]]