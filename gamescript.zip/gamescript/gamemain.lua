
function __G__TRACKBACK__(msg)
print("----------------------------------------")
print("LUA ERROR: " .. tostring(msg) .. "\n")
print(debug.traceback())
print("----------------------------------------")
end

require "gamescript/extern"
require "gamescript/fightData/boss1"
require "gamescript/fightData/fight"
require "gamescript/formula"
require "gamescript/gameMenu/CDungeonsMenuScene"
require "gamescript/HeroSkillsSelect/HeroAndSkillSelectScene"
require "gamescript/HeroSkillsSelect/Hero_Head_TableView"
require "gamescript/HeroSkillsSelect/CSkillsprite"
require "gamescript/HeroSkillsSelect/Hero_Skill_View"

require "gamescript/formationScene/CFormationScene" 

require "gamescript/cocos2dx/CCNodeExtend"
require "gamescript/cocos2dx/CCLayerExtend"
require "gamescript/cocos2dx/CCSceneExtend"
require "gamescript/cocos2dx/CCSpriteExtend"
require "gamescript/cocos2dx/display"
require "gamescript/cocos2dx/functions"
 
g_cocos2dx_display = require "gamescript/cocos2dx/display"
g_cocos2dx_ui = require "gamescript/cocos2dx/ui"
g_cocos2dx_schedule = require "gamescript/cocos2dx/scheduler"

--------------------------------脚本程序入口--------------------------------
local function main()
 
    local pFileUtils = CCFileUtils:sharedFileUtils();
    pFileUtils:addSearchPath("data");
    pFileUtils:addSearchPath("data/levels/FightScene");
    pFileUtils:addSearchPath("data/levels/dungeon_RagefireChasm");
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)

    print("main run!")
   

  --ShowHeroAndSkillSelectScene()
  ShowDungeonsMenuScene()
  --showFormationScene()
end   
-------------------------------布阵界面-------------------------------------

function showFormationScene()
    g_FormationScene = CFormationScene:new()
    if(CCDirector:sharedDirector():getRunningScene() == nil)then
      CCDirector:sharedDirector():runWithScene(g_FormationScene)
      print("runWithScene: g_FormationScene")
    else
      CCDirector:sharedDirector():replaceScene(g_FormationScene)
      print("replaceScene : g_FormationScene")
    end    
end     
  
--------------------------------战斗loading界面------------------------------------------
function ShowFightLoadingScene( dungeondId )
    local Scene = CLoadingScene:Show()
    local tab = CClientLoader:GetInstance():GetBaseDataFromId("dungeondata", dungeondId);
    local cjson = require "cjson"
    local jsonData = cjson.decode(tab)

    Scene:registerScriptHandler( CDungeonsMenuScene.onLoadEndCallBack )
    Scene:setTag(dungeondId)

    local id = {}
    for i,v in ipairs(jsonData.animationres) do
         id[i] = v
    end

    local param = cjson.encode( id )
    print("param="..param)
    Scene:LoadingArmatureData( param )

    local id = {}
    for i,v in ipairs(jsonData.effectres) do 
        id[i] = v
    end 
  
    local param = cjson.encode( id )
    Scene:LoadingArmatureData( param ) 
     
end   

-------------------------------副本菜单-------------------------------------
function ShowDungeonsMenuScene()

   g_DungeonsMenuScene =  CDungeonsMenuScene:new()
if( CCDirector:sharedDirector():getRunningScene() == nil )then
   CCDirector:sharedDirector():runWithScene(g_DungeonsMenuScene)
   print("runWithScene")
else
   CCDirector:sharedDirector():replaceScene( g_DungeonsMenuScene );
   print("replaceScene")
end
   --g_DungeonsMenuScene:registerScriptHandler(CDungeonsMenuScene.onDungeonsMenuSceneEvnet)
end
 

-------------------------------进入技能选择菜单-------------------------------------
function ShowHeroAndSkillSelectScene()

    g_HeroAndSkillSelectScene = HeroAndSkillSelectScene:new()
if( CCDirector:sharedDirector():getRunningScene() == nil )then
    CCDirector:sharedDirector():runWithScene(g_HeroAndSkillSelectScene)
    print("runWithScene-->g_HeroAndSkillSelectScene")
else
    CCDirector:sharedDirector():replaceScene( g_HeroAndSkillSelectScene );
    print("replaceScene-->g_HeroAndSkillSelectScene")
end
    g_HeroAndSkillSelectScene:registerScriptHandler(HeroAndSkillSelectScene.onHeroAndSkillSelectSceneEvnet)

end
--------------------------called by c++ -----------------------------------
function onGameFightEndCallBack()
    ShowDungeonsMenuScene()
end
--------------------------------------------------------------------

xpcall(main, __G__TRACKBACK__)