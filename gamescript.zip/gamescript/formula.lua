
function GetMonsterHp( level, param1)
	-- body
	return level * param1;
end

function GetPlayerHp( level, param1 )
	-- body
	return level * param1;
end

function GetMeleeDef( level, param1)
	-- body
	return level* param1;
end

function GetMageDef( level, param1)
	-- body
	return level * param1;
end

function GetMeleeAtk( level, param1 )
	-- body
	return level * param1;
end

function GetMageAtk( level, param1 )
	-- body
	return level * param1;
end