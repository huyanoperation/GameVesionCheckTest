require "gamescript/extern"

CDungeonsMenuScene = class( "CDungeonsMenuScene", function()
	return g_cocos2dx_display.newScene()
end )

CDungeonsMenuScene.__index = CDungeonsMenuScene

-----------------------------------读起副本菜单UI--------------------------------------

function CDungeonsMenuScene:LoadUI()
    print("UI LOAD")
    local pLayer = CCLayer:create()
    self:addChild(pLayer)

    local render = SceneReader:sharedSceneReader():createNodeWithSceneFile("data/levels/dungeon_RagefireChasm/dungeon_RagefireChasm.json")
    self:addChild( render )

    local uiLayer =  UILayer:create()
    self.uiLayer = uiLayer
    self:addChild( uiLayer, 1 )
    local pUIWidget = GUIReader:shareReader():widgetFromJsonFile("data/ui/dungeonSelect.json")
    pUIWidget:getChildByName("dungeon_RagefireChasm__chooseButton"):registerEventScript( CDungeonsMenuScene.onDungeonsMenuSceneButtonCallBack )
    pUIWidget:getChildByName("dungeon_OnyxiasLair_chooseButton"):registerEventScript( CDungeonsMenuScene.onDungeonsMenuSceneButtonCallBack )
    uiLayer:addWidget( pUIWidget )

end

--------------------------------------模拟onEnter-----------------------------------------------

function CDungeonsMenuScene:onEnter()
    -- body
    self:LoadUI()
    print("CDungeonsMenuScene:onEnter")
end
---------------------------------- 菜单回调函数 called by c++ ---------------------------------------

function CDungeonsMenuScene.onDungeonsMenuSceneEvnet( eventType )


end

---------------------------------- 战斗入口 called by c++ ----------------------------------------

function CDungeonsMenuScene.onDungeonsMenuSceneButtonCallBack( eventType,data )

    print("eventType=",eventType  )
    print( data:getName() )

    if( eventType == "releaseUp" )then
        if( data:getName() == "dungeon_OnyxiasLair_chooseButton"  )then
            ShowFightLoadingScene(1)
        end
        if( data:getName() == "dungeon_RagefireChasm__chooseButton"  )then
            ShowFightLoadingScene(2)
        end
    end

end


function CDungeonsMenuScene.onLoadEndCallBack( eventTag )
   print( "eventTag = "..eventTag )
    if eventTag == 1 then
        CFightScene:Show("{\"scenePath\": \"data/levels/FightScene/Onyxia.json\", \"dungeonID\": 1 }")
    end
   if eventTag == 2 then
        CFightScene:Show( "{\"scenePath\": \"data/levels/dungeon_RagefireChasm/dungeon_RagefireChasm.json\", \"dungeonID\": 2 }")
   end
end