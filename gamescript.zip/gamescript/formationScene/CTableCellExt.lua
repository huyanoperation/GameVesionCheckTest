require "gamescript/extern"

CTableCellExt = class("CTableCellExt", function (  )
	return CCTableViewCell:new()
end)

CTableCellExt.__index = CTableCellExt

-- function CTableCellExt.extend( target )
-- 	local t = tolua.getpeer(target)
-- 	if not t then
-- 		t = {}
-- 		tolua.setpeer(target, t)
-- 	end
-- 	setmetatable(t, CTableCellExt)
-- 	return target
-- end

-- function CTableCellExt.create()
--     local layer = CTableCellExt.extend(CCSprite:create())
--     if nil ~= layer then
--         layer:init()
--     end

--     return layer
-- end

function CTableCellExt:init(  )
	print("CTableCellExt:init()")
	local mainLayer = CCLayerColor:create(ccc4(55, 55, 255, 255))
	self:addChild(mainLayer)
end

function CTableCellExt:onEnter(  )
	print("CTableCellExt:onEnter")
	self:init()
end