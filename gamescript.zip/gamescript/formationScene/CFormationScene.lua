require "gamescript/extern"
require "gamescript/formationScene/CHeroSelectLayer"

CFormationScene = class("CFormationScene", function()
	return g_cocos2dx_display.newScene()
end)

CFormationScene.__index = CFormationScene

function CFormationScene:loadUI()
	print("CFormationScene:loadUI called ==== begin")

	local winSize = CCDirector:sharedDirector():getWinSize()
	
	-- 主界面的layer
	local mainLayer = CCLayerColor:create(ccc4(55, 55, 55, 255))	
	self:addChild(mainLayer)

	-- 左侧的英雄排列位置layer
	local leftLayer = CCLayerColor:create(ccc4(115, 5, 25, 255), winSize.width * 0.5, winSize.height)
	mainLayer:addChild(leftLayer)

	-- 获取列表显示所需数据
	local tableData = self:getTableData()
	-- 右侧的英雄选择layer
	local rightLayer = CHeroSelectLayer.create(tableData)
	mainLayer:addChild(rightLayer)
	rightLayer:ignoreAnchorPointForPosition(false)
	rightLayer:setAnchorPoint(ccp(0, 0))
	rightLayer:setPosition(ccp(winSize.width * 0.5, 0))
	

	print("CFormationScene:loadUI called ==== end")
end

function CFormationScene:onEnter()
	print("CFormationScene:onEnter")

	self:loadUI()
end

-- 获取列表的数据
function CFormationScene:getTableData()
	print("CFormationScene:getTableData")

	local data = {}
	local cellContentInfo = {  }
	local cellConfigInfo = { numOfCells = 10, cellWidth = 244, cellHeight = 154}
	data["cellConfigInfo"] = cellConfigInfo
	data["cellContentInfo"] = cellContentInfo

	return data
end

