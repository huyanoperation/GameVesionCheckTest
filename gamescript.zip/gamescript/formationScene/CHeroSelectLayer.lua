require "gamescript/extern"
require "gamescript/formationScene/CTableCellExt"

CHeroSelectLayer = class("CHeroSelectLayer")

CHeroSelectLayer.__index = CHeroSelectLayer

-- 英雄列表的数据，
local tableData = {}
-- -- 单元格内容的数据，单个英雄的数据
-- local cellContentInfo = {}
-- -- 单元格的属性数据等
-- local cellConfigInfo = {spacingVer = 0, spacingHer = 0, numOfCells = 0, width = 0, height = 0}
-- tableData["cellContent"] = cellContentInfo
-- tableData["cellConfig"] = cellConfigInfo


function CHeroSelectLayer.extend( target )
	local t = tolua.getpeer(target)
	if not t then
		t = {}
		tolua.setpeer(target, t)
	end
	setmetatable(t, CHeroSelectLayer)
	return target
end

function CHeroSelectLayer.create(var)
    tableData = var
    local layer = CHeroSelectLayer.extend(CCLayer:create())
    if nil ~= layer then
        layer:init()
    end

    return layer
end

function CHeroSelectLayer:init()
	-- body

	print("CHeroSelectLayer:init")
	local winSize = CCDirector:sharedDirector():getWinSize()

	local tableView = CCTableView:create(CCSizeMake(winSize.width * 0.5 - 40, winSize.height - 50))
    tableView:setDirection(kCCScrollViewDirectionVertical)
    tableView:setPosition(CCPointMake(20, 25))
    tableView:setViewSize(CCSizeMake(winSize.width * 0.5 - 40, winSize.height - 50))
    self:addChild(tableView)
    --registerScriptHandler functions must be before the reloadData function
    tableView:registerScriptHandler(CHeroSelectLayer.scrollViewDidScroll,CCTableView.kTableViewScroll)
    tableView:registerScriptHandler(CHeroSelectLayer.scrollViewDidZoom,CCTableView.kTableViewZoom)
    tableView:registerScriptHandler(CHeroSelectLayer.tableCellTouched,CCTableView.kTableCellTouched)
    tableView:registerScriptHandler(CHeroSelectLayer.cellSizeForTable,CCTableView.kTableCellSizeForIndex)
    tableView:registerScriptHandler(CHeroSelectLayer.tableCellAtIndex,CCTableView.kTableCellSizeAtIndex)
    tableView:registerScriptHandler(CHeroSelectLayer.numberOfCellsInTableView,CCTableView.kNumberOfCellsInTableView)  
    tableView:reloadData()
    print("table initialized")
end


--按钮回调方法
function CHeroSelectLayer:onButtonCallBack(  )
    print("onButtonCallBack")
end


-- 列表的代理方法
function CHeroSelectLayer.scrollViewDidScroll(view)
    -- print("scrollViewDidScroll")
end

function CHeroSelectLayer.scrollViewDidZoom(view)
    -- print("scrollViewDidZoom")
end

function CHeroSelectLayer.tableCellTouched(table,cell)
    print("cell touched at index: " .. cell:getIdx())
end

function CHeroSelectLayer.cellSizeForTable(table,idx) 
    return tableData["cellConfigInfo"].cellHeight, tableData["cellConfigInfo"].cellWidth
end

function CHeroSelectLayer.tableCellAtIndex(table, idx)
    local strValue = string.format("%d",idx)
    local cell = table:dequeueCell()
    local label = nil

    if nil == cell then
        cell = CTableCellExt:new()
        -- cell:init()
        
        local sprite = CCSprite:create("data/ui/dunqiang.png")
        sprite:setAnchorPoint(CCPointMake(0,0))
        sprite:setPosition(CCPointMake(0, 0))
        cell:addChild(sprite)

        label = CCLabelTTF:create(strValue, "Helvetica", 20.0)
        label:setPosition(CCPointMake(0,0))
        label:setAnchorPoint(CCPointMake(0,0))
        label:setTag(123)
        cell:addChild(label)



        -- local pUIWidget = GUIReader:shareReader():widgetFromJsonFile("data/ui/UI_LineUp_1/UI_LineUp_1.json")
        -- pUIWidget:getChildByName("button"):registerEventScript( CHeroSelectLayer.onButtonCallBack )
        -- cell:addWidget( pUIWidget )


    else
        label = tolua.cast(cell:getChildByTag(123),"CCLabelTTF")
        if nil ~= label then
            label:setString(strValue)
        end
    end

    return cell
end

function CHeroSelectLayer.numberOfCellsInTableView(table)
   return tableData["cellConfigInfo"].numOfCells
end